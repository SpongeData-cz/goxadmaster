echo s1
